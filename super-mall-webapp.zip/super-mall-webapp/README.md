# Super Mall Web Application
Manage Shops, Offers, Products & Locations (Floors/Categories) with Firebase.

## Tech Stack
- HTML, CSS, JavaScript (ES Modules)
- Firebase (Auth, Firestore, Storage, Hosting)
- Modular, testable code with a lightweight logging utility

## Features
- Admin
  - Login (Firebase Auth)
  - Create/Manage: Shops, Products, Offers, Categories, Floors
  - View lists, filter by Category/Floor, Shop-wise offers
  - Activity Logging for every action
- User
  - Browse and filter products
  - View shop details and shop-wise/floor-wise items
  - Compare products (cost & features)
- Logging
  - Client-side logging to Firestore collection `logs` for each action
  - Console logs with levels (info, warn, error, debug)

## Project Structure
```
super-mall-webapp/
├─ index.html                # User view (browse/filter/compare)
├─ login.html                # Auth page
├─ admin.html                # Admin dashboard (CRUD)
├─ shop.html                 # Shop details page
├─ assets/
│  └─ styles.css
├─ src/
│  ├─ firebase.js            # Firebase init (fill your config)
│  ├─ auth.js                # Auth helpers & guards
│  ├─ logging.js             # Logging helpers
│  ├─ main.js                # App bootstrap (index)
│  ├─ ui/
│  │  └─ render.js           # DOM rendering helpers
│  ├─ features/
│  │  ├─ filter.js           # Filtering logic
│  │  └─ compare.js          # Product compare logic
│  └─ data/
│     ├─ shops.js
│     ├─ products.js
│     ├─ offers.js
│     ├─ categories.js
│     └─ floors.js
├─ firestore.rules           # Security rules (example)
├─ storage.rules             # Storage rules (example)
├─ firebase.json             # Hosting config (example)
└─ README.md
```

## Quick Start
1. **Create Firebase project** at https://console.firebase.google.com
2. Enable:
   - **Authentication** → Sign-in method → Email/Password
   - **Firestore** (in production or test mode, then tighten rules)
   - **Storage** (for product images)
   - **Hosting** (optional for deployment)
3. In `src/firebase.js`, replace `YOUR_...` with your Firebase config from **Project settings → Web app**.
4. Serve locally (any static server). Examples:
   - Python: `python -m http.server 8080` then open `http://localhost:8080`
   - VS Code Live Server extension
5. Create at least one **admin user**:
   - Sign up on `/login.html`, then set the user role in Firestore:
     - Add a document in `users/{uid}` with `{ email, role: "admin", createdAt }`.

## Deploy (Firebase Hosting)
```
npm install -g firebase-tools
firebase login
firebase init hosting  # choose 'dist' as public dir or '.'; single-page app: 'No'
firebase deploy
```

## Basic Workflow
- **Admin** opens `admin.html` to manage Shops/Products/Offers/Categories/Floors.
- **User** opens `index.html` to browse, filter, and compare products.
- **Logs** are written to Firestore in `logs` collection with `action`, `actor`, `meta`, and `ts`.

## Testing Notes
- Each module is pure where possible and can be unit-tested.
- Separate concerns: data access in `/src/data/*`, UI in `/src/ui`, features in `/src/features`.

## Security Notes
- Example rules are included in `firestore.rules` and `storage.rules`. Tailor to your needs.
- Consider Cloud Functions to enforce server-side constraints if needed.

## Future Enhancements
- Pagination & search indexing
- Cloud Functions to validate offers, maintain denormalized counters
- Role-based UI routing and guard improvements

---

**Author:** Ranjeet Kumar  
**License:** MIT
