import { db, collection, getDocs, addDoc, doc, updateDoc, deleteDoc } from '../firebase.js';
import { logEvent } from '../logging.js';

export async function listFloors() {
  const snap = await getDocs(collection(db, 'floors'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function upsertFloor(data) {
  if (data.id) {
    const { id, ...rest } = data;
    await updateDoc(doc(db, 'floors', id), rest);
    await logEvent('floor.update', { id, ...rest });
    return id;
  } else {
    const ref = await addDoc(collection(db, 'floors'), data);
    await logEvent('floor.create', { id: ref.id, ...data });
    return ref.id;
  }
}

export async function removeFloor(id) {
  await deleteDoc(doc(db, 'floors', id));
  await logEvent('floor.delete', { id });
}
