import { auth } from './firebase.js';
import { requireAdmin } from './auth.js';
import { upsertShop, listShops, removeShop } from './data/shops.js';
import { upsertCategory, listCategories, removeCategory } from './data/categories.js';
import { upsertFloor, listFloors, removeFloor } from './data/floors.js';
import { upsertProduct, listProducts, removeProduct } from './data/products.js';
import { upsertOffer, listOffers, removeOffer } from './data/offers.js';
import { logEvent } from './logging.js';

function byId(id){ return document.getElementById(id); }

function row(items) {
  const div = document.createElement('div');
  div.className = 'row';
  items.forEach(el => div.appendChild(el));
  return div;
}

function makeBtn(text, onclick) {
  const b = document.createElement('button'); b.className='btn'; b.textContent=text; b.onclick=onclick; return b;
}

async function refreshLists() {
  // Shops
  const shops = await listShops();
  const sDiv = byId('shops-list'); sDiv.innerHTML='';
  shops.forEach(s => sDiv.appendChild(row([
    document.createTextNode(`${s.id} — ${s.name} — floor:${s.floorId} — cat:${s.categoryId}`),
    makeBtn('Edit', () => fillForm('form-shop', s)),
    makeBtn('Delete', async () => { await removeShop(s.id); refreshLists(); })
  ])));
  // Categories
  const cats = await listCategories();
  const cDiv = byId('categories-list'); cDiv.innerHTML='';
  cats.forEach(c => cDiv.appendChild(row([
    document.createTextNode(`${c.id} — ${c.name}`),
    makeBtn('Edit', () => fillForm('form-category', c)),
    makeBtn('Delete', async () => { await removeCategory(c.id); refreshLists(); })
  ])));
  // Floors
  const fl = await listFloors();
  const fDiv = byId('floors-list'); fDiv.innerHTML='';
  fl.forEach(f => fDiv.appendChild(row([
    document.createTextNode(`${f.id} — ${f.name}`),
    makeBtn('Edit', () => fillForm('form-floor', f)),
    makeBtn('Delete', async () => { await removeFloor(f.id); refreshLists(); })
  ])));
  // Products
  const prods = await listProducts({});
  const pDiv = byId('products-list'); pDiv.innerHTML='';
  prods.forEach(p => pDiv.appendChild(row([
    document.createTextNode(`${p.id} — ${p.name} — ₹${p.price} — shop:${p.shopId}`),
    makeBtn('Edit', () => fillForm('form-product', { ...p, features: JSON.stringify(p.features || {}) })),
    makeBtn('Delete', async () => { await removeProduct(p.id); refreshLists(); })
  ])));
  // Offers
  const offers = await listOffers();
  const oDiv = byId('offers-list'); oDiv.innerHTML='';
  offers.forEach(o => oDiv.appendChild(row([
    document.createTextNode(`${o.id} — ${o.title} — ${o.discountPct}% — shop:${o.shopId || '-'} product:${o.productId || '-'}`),
    makeBtn('Edit', () => fillForm('form-offer', o)),
    makeBtn('Delete', async () => { await removeOffer(o.id); refreshLists(); })
  ])));
}

function fillForm(formId, data) {
  const form = byId(formId);
  Array.from(form.elements).forEach(el => {
    if (!el.name) return;
    if (el.name === 'features' && typeof data.features !== 'string') {
      el.value = JSON.stringify(data.features || {});
    } else {
      el.value = data[el.name] ?? '';
    }
  });
}

function values(form) {
  const obj = {};
  Array.from(form.elements).forEach(el => { if (el.name) obj[el.name] = el.value; });
  return obj;
}

window.addEventListener('DOMContentLoaded', async () => {
  const adminInfo = byId('admin-info');
  try {
    await requireAdmin(adminInfo);
  } catch {
    return;
  }

  // handle forms
  byId('form-shop').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values(e.target);
    await upsertShop({ id: v.id || undefined, name: v.name, floorId: v.floorId, categoryId: v.categoryId, owner: v.owner || '' });
    e.target.reset(); refreshLists();
  });

  byId('form-category').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values(e.target);
    await upsertCategory({ id: v.id || undefined, name: v.name });
    e.target.reset(); refreshLists();
  });

  byId('form-floor').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values(e.target);
    await upsertFloor({ id: v.id || undefined, name: v.name });
    e.target.reset(); refreshLists();
  });

  byId('form-product').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values(e.target);
    let features = {};
    try { features = v.features ? JSON.parse(v.features) : {}; } catch { alert('Invalid JSON in features'); return; }
    await upsertProduct({ id: v.id || undefined, name: v.name, price: Number(v.price), shopId: v.shopId, categoryId: v.categoryId, floorId: v.floorId, features, imageUrl: v.imageUrl || '' });
    e.target.reset(); refreshLists();
  });

  byId('form-offer').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values(e.target);
    await upsertOffer({ id: v.id || undefined, title: v.title, shopId: v.shopId || '', productId: v.productId || '', discountPct: Number(v.discountPct), validUntil: v.validUntil });
    e.target.reset(); refreshLists();
  });

  await refreshLists();
});
