export function applyFilters(products, { text='', categoryId='', floorId='', shopId='' } = {}) {
  const t = text.trim().toLowerCase();
  return products.filter(p => {
    if (t && !p.name.toLowerCase().includes(t)) return false;
    if (categoryId && p.categoryId !== categoryId) return false;
    if (floorId && p.floorId !== floorId) return false;
    if (shopId && p.shopId !== shopId) return false;
    return true;
  });
}
