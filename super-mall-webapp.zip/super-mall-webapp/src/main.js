import { watchAuthLink } from './auth.js';
import { listProducts } from './data/products.js';
import { listCategories } from './data/categories.js';
import { listFloors } from './data/floors.js';
import { listShops } from './data/shops.js';
import { applyFilters } from './features/filter.js';
import { renderProductCard, renderCompareBar } from './ui/render.js';

function byId(id){ return document.getElementById(id); }

async function populateFilters() {
  const [cats, floors, shops] = await Promise.all([listCategories(), listFloors(), listShops()]);
  const selCat = byId('filter-category');
  const selFloor = byId('filter-floor');
  const selShop = byId('filter-shop');
  for (const c of cats) selCat.append(new Option(c.name, c.id));
  for (const f of floors) selFloor.append(new Option(f.name, f.id));
  for (const s of shops) selShop.append(new Option(s.name, s.id));
  const urlShop = new URLSearchParams(location.search).get('shop');
  if (urlShop) selShop.value = urlShop;
}

async function loadProducts() {
  const selCat = byId('filter-category').value;
  const selFloor = byId('filter-floor').value;
  const selShop = byId('filter-shop').value;
  const text = byId('filter-text').value;

  let products = await listProducts({});
  products = applyFilters(products, { text, categoryId: selCat, floorId: selFloor, shopId: selShop });

  const container = byId('product-list');
  container.innerHTML = '';
  products.forEach(p => container.appendChild(renderProductCard(p)));
  renderCompareBar(byId('compare-bar'));
}

window.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('year').textContent = new Date().getFullYear();
  watchAuthLink(document.getElementById('auth-link'));
  await populateFilters();
  await loadProducts();
  byId('btn-apply-filter').onclick = loadProducts;
  byId('btn-clear-filter').onclick = () => { byId('filter-category').value=''; byId('filter-floor').value=''; byId('filter-shop').value=''; byId('filter-text').value=''; loadProducts(); };
});
