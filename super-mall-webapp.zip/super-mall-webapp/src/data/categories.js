import { db, collection, getDocs, addDoc, doc, updateDoc, deleteDoc } from '../firebase.js';
import { logEvent } from '../logging.js';

export async function listCategories() {
  const snap = await getDocs(collection(db, 'categories'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function upsertCategory(data) {
  if (data.id) {
    const { id, ...rest } = data;
    await updateDoc(doc(db, 'categories', id), rest);
    await logEvent('category.update', { id, ...rest });
    return id;
  } else {
    const ref = await addDoc(collection(db, 'categories'), data);
    await logEvent('category.create', { id: ref.id, ...data });
    return ref.id;
  }
}

export async function removeCategory(id) {
  await deleteDoc(doc(db, 'categories', id));
  await logEvent('category.delete', { id });
}
