import { auth, onAuthStateChanged, signOut, db, doc, getDoc } from './firebase.js';
import { logEvent } from './logging.js';

export function watchAuthLink(anchorEl) {
  onAuthStateChanged(auth, (u) => {
    if (u) {
      anchorEl.textContent = 'Logout';
      anchorEl.href = '#';
      anchorEl.onclick = async (e) => {
        e.preventDefault();
        await logEvent('logout', { email: u.email });
        await signOut(auth);
        location.reload();
      };
    } else {
      anchorEl.textContent = 'Login';
      anchorEl.href = './login.html';
      anchorEl.onclick = null;
    }
  });
}

export async function requireAdmin(targetInfoEl) {
  return new Promise((resolve, reject) => {
    onAuthStateChanged(auth, async (u) => {
      if (!u) {
        targetInfoEl.textContent = 'Not logged in. Redirecting to login...';
        setTimeout(() => location.href = 'login.html', 1200);
        return reject(new Error('Not logged in'));
      }
      const userDoc = await getDoc(doc(db, 'users', u.uid));
      const role = userDoc.exists() ? userDoc.data().role : 'user';
      if (role !== 'admin') {
        targetInfoEl.textContent = 'Access denied. Admins only.';
        return reject(new Error('Not admin'));
      }
      targetInfoEl.textContent = `Welcome, ${u.email} (admin)`;
      resolve(u);
    });
  });
}
