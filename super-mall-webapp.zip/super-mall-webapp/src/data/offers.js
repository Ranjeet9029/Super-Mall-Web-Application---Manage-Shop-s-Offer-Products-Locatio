import { db, collection, getDocs, addDoc, doc, updateDoc, deleteDoc } from '../firebase.js';
import { logEvent } from '../logging.js';

export async function listOffers() {
  const snap = await getDocs(collection(db, 'offers'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function upsertOffer(data) {
  if (data.id) {
    const { id, ...rest } = data;
    await updateDoc(doc(db, 'offers', id), rest);
    await logEvent('offer.update', { id, ...rest });
    return id;
  } else {
    const ref = await addDoc(collection(db, 'offers'), data);
    await logEvent('offer.create', { id: ref.id, ...data });
    return ref.id;
  }
}

export async function removeOffer(id) {
  await deleteDoc(doc(db, 'offers', id));
  await logEvent('offer.delete', { id });
}
