import { addToCompare, getCompareList, removeFromCompare } from '../features/compare.js';

export function el(tag, className, html) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (html) e.innerHTML = html;
  return e;
}

export function renderProductCard(p, shopName='') {
  const card = el('div','item');
  card.innerHTML = `
    <img class="thumb" src="${p.imageUrl || 'https://picsum.photos/400/240?blur=1'}" alt="${p.name}"/>
    <h3>${p.name}</h3>
    <div class="price">₹ ${Number(p.price).toLocaleString()}</div>
    <div class="badge">Shop: ${shopName || p.shopId}</div>
    <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px"></div>
  `;
  const row = card.querySelector('.row');
  const btnCompare = el('button','btn','Add to Compare');
  btnCompare.onclick = () => addToCompare(p);
  row.appendChild(btnCompare);
  return card;
}

export function renderShopCard(s) {
  const card = el('div','item');
  card.innerHTML = `
    <h3>${s.name}</h3>
    <div class="badge">Floor: ${s.floorId}</div>
    <div class="badge">Category: ${s.categoryId}</div>
    <div style="margin-top:8px">
      <a class="btn" href="index.html?shop=${s.id}">View Products</a>
    </div>
  `;
  return card;
}

export function renderCompareBar(container) {
  const list = getCompareList();
  container.innerHTML = '';
  if (list.length === 0) {
    container.textContent = 'No products added for comparison yet.';
    return;
  }
  list.forEach(p => {
    const chip = el('span','pill',`${p.name} (₹${p.price})`);
    const x = el('a', null, ' ×');
    x.href = '#';
    x.onclick = (e) => { e.preventDefault(); removeFromCompare(p.id); renderCompareBar(container); };
    chip.appendChild(x);
    container.appendChild(chip);
  });
}

export function renderCompareTable(container) {
  const list = getCompareList();
  if (list.length === 0) {
    container.innerHTML = '<p>No items to compare.</p>';
    return;
  }
  const keys = new Set(['name','price']);
  list.forEach(p => Object.keys(p.features || {}).forEach(k => keys.add(k)));
  const cols = Array.from(keys);
  let html = '<div class="item"><table style="width:100%;border-collapse:collapse">';
  html += '<tr>' + cols.map(c => `<th style="text-align:left;border-bottom:1px solid #eee;padding:6px">${c}</th>`).join('') + '</tr>';
  list.forEach(p => {
    html += '<tr>';
    cols.forEach(c => {
      let v = p[c];
      if (c !== 'name' && c !== 'price') v = (p.features || {})[c];
      if (c === 'price') v = `₹ ${Number(p.price).toLocaleString()}`;
      html += `<td style="border-bottom:1px solid #f3f3f3;padding:6px">${v ?? '-'}</td>`;
    });
    html += '</tr>';
  });
  html += '</table></div>';
  container.innerHTML = html;
}
