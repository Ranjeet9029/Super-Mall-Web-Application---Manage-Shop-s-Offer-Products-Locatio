import { db, addDoc, collection, serverTimestamp } from './firebase.js';

const LEVELS = ['debug','info','warn','error'];

export async function logEvent(action, meta = {}, level = 'info', actor = null) {
  try {
    if (!LEVELS.includes(level)) level = 'info';
    const payload = {
      action,
      level,
      meta,
      actor: actor || (meta && meta.email) || null,
      ts: serverTimestamp()
    };
    console.log(`[${level.toUpperCase()}]`, action, meta);
    await addDoc(collection(db, 'logs'), payload);
  } catch (err) {
    console.error('Failed to log event', err);
  }
}
