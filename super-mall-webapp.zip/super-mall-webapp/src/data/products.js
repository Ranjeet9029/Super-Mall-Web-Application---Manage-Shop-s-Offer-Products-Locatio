import { db, collection, getDocs, addDoc, doc, updateDoc, deleteDoc, query, where } from '../firebase.js';
import { logEvent } from '../logging.js';

export async function listProducts(filters = {}) {
  const col = collection(db, 'products');
  const qs = [];
  if (filters.shopId) qs.push(where('shopId','==',filters.shopId));
  if (filters.categoryId) qs.push(where('categoryId','==',filters.categoryId));
  if (filters.floorId) qs.push(where('floorId','==',filters.floorId));
  const snap = await getDocs(qs.length ? query(col, ...qs) : col);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function listProductsByShop(shopId) {
  return listProducts({ shopId });
}

export async function upsertProduct(data) {
  if (data.id) {
    const { id, ...rest } = data;
    await updateDoc(doc(db, 'products', id), rest);
    await logEvent('product.update', { id, ...rest });
    return id;
  } else {
    const ref = await addDoc(collection(db, 'products'), data);
    await logEvent('product.create', { id: ref.id, ...data });
    return ref.id;
  }
}

export async function removeProduct(id) {
  await deleteDoc(doc(db, 'products', id));
  await logEvent('product.delete', { id });
}
