const KEY = 'supermall_compare';

function read() {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); }
  catch { return []; }
}
function write(list) { localStorage.setItem(KEY, JSON.stringify(list)); }

export function addToCompare(p) {
  const list = read();
  if (!list.find(x => x.id === p.id)) {
    list.push({ id: p.id, name: p.name, price: p.price, features: p.features || {} });
    write(list);
    alert('Added to compare');
  }
}
export function removeFromCompare(id) {
  const list = read().filter(x => x.id !== id);
  write(list);
}
export function getCompareList() { return read(); }
