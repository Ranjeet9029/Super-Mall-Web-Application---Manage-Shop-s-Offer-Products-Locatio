import { db, collection, getDocs, addDoc, doc, setDoc, updateDoc, deleteDoc } from '../firebase.js';
import { logEvent } from '../logging.js';

export async function listShops() {
  const snap = await getDocs(collection(db, 'shops'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function upsertShop(data) {
  if (data.id) {
    const { id, ...rest } = data;
    await updateDoc(doc(db, 'shops', id), rest);
    await logEvent('shop.update', { id, ...rest });
    return id;
  } else {
    const ref = await addDoc(collection(db, 'shops'), data);
    await logEvent('shop.create', { id: ref.id, ...data });
    return ref.id;
  }
}

export async function removeShop(id) {
  await deleteDoc(doc(db, 'shops', id));
  await logEvent('shop.delete', { id });
}
